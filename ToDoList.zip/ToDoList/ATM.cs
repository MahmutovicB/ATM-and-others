﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TextBox = System.Windows.Forms.TextBox;

namespace ToDoList
{
	public partial class ATM : Form
	{
		private Banka bank;
		public ATM()
		{
			InitializeComponent();
			bank = AppData.Bank;
		}

		private void ATM_Load(object sender, EventArgs e)
		{

		}

		private void button2_Click(object sender, EventArgs e)
		{
			this.Hide();
			new ATMSignUp().ShowDialog();
			this.Close();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			if (textBox1.Text == "" || textBox2.Text == "")
			{
				MessageBox.Show("Please fill all fields!");
			}
			else
			{
				if (bank.checkRacun(int.Parse(textBox1.Text), int.Parse(textBox2.Text)))
				{
					this.Hide();
					new ATMMenu(int.Parse(textBox1.Text), int.Parse(textBox2.Text)).ShowDialog();
					this.Close();
				}
				else
				{
					MessageBox.Show("Wrong account number or password!");
				}
			}
		}
	}
}
