﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ToDoList
{
	public partial class ATMSignUp : Form
	{
		private Banka bank;
		public ATMSignUp()
		{
			InitializeComponent();
			bank = AppData.Bank;
		}

		private void button2_Click(object sender, EventArgs e)
		{
			this.Hide();
			new ATM().ShowDialog();
			this.Close();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")
			{
				MessageBox.Show("Please fill all fields!");
			}
			else
			{
				if (textBox2.Text != textBox5.Text)
				{
					MessageBox.Show("Passwords do not match!");
				}
				else
				{
					MessageBox.Show("Account created successfully!");
					Racun temp = new Racun(int.Parse(textBox1.Text), int.Parse(textBox2.Text), 0, textBox3.Text, textBox4.Text);
					bank.addRacun(temp);
					this.Hide();
					new ATM().ShowDialog();
					this.Close();
				}
			}
		}

		
	}
}
